/**
 * Copyright (c) LCH Clearnet Ltd 2013
 */
package com.lchclearnet.swapclear.smart.sample;

import java.util.ArrayList;

import com.lchclearnet.dates.data.DateUtils;
import com.lchclearnet.dates.data.SimpleDate;
import com.lchclearnet.swapclear.smart.SMART;
import com.lchclearnet.swapclear.smart.SMARTDataProviderFactory;
import com.lchclearnet.swapclear.smart.SMARTFactory;
import com.lchclearnet.swapclear.smart.SMARTSession;
import com.lchclearnet.swapclear.smart.data.DataProviderFactory;
import com.lchclearnet.swapclear.smart.types.Account;
import com.lchclearnet.swapclear.smart.types.Date;
import com.lchclearnet.swapclear.smart.types.Leg;
import com.lchclearnet.swapclear.smart.types.LegType;
import com.lchclearnet.swapclear.smart.types.SensitivityProfile;
import com.lchclearnet.swapclear.smart.types.SimulationSet;
import com.lchclearnet.swapclear.smart.types.SmartResultSet;
import com.lchclearnet.swapclear.smart.types.Trade;
import com.lchclearnet.swapclear.smart.types.TradeId;
import com.lchclearnet.swapclear.smart.types.TradeType;
import com.lchclearnet.swapclear.smart.types.TradeValuation;

/**
 * A sample application to demonstrate the use of the Smart API.
 */
public class ValueSwap {

    public static void main(String[] args) {
        // Location of reports
        String reportBasePath = "../SampleReports";
        // The date for which we want to use Smart - reports must be
        // available for this date
        String businessDate = "23/06/2014";
        // The party for which we want to generate IM
        // Must use a dummy party if the party reports are not available
        String party = "XXX";
        // Optional account
        String account = null; // = "H";

        // We start by getting a DataProviderFactory which will
        // be tied to a report location
        DataProviderFactory dataProviderFactory = new SMARTDataProviderFactory(reportBasePath);
        // DataProviderFactory dataProviderFactory = new SMARTClientDataProviderFactory("user.email@lchclearnet.com", "password");
        // Construct a date object representing business date
        SimpleDate date = DateUtils.makeDate(businessDate);
        // Instantiate the SMART Factory
        SMARTFactory smartFactory = new SMARTFactory();
        // Set data provider factory and reporting currency
        smartFactory.setDataProviderFactory(dataProviderFactory);
        smartFactory.setReportingCurrency("GBP");
        // Obtain an instance of SMART tied to the business date
        // Reports must be available for the given date
        SMART smart = smartFactory.getSMARTInstance(date);
        
        // Start a session 
        // The second boolean parameter says that we want the trades
        // and sensitivities to be cached in the session 
        // Please see the JavaDoc documentation of SMARTSession
        // for an explanation of caching and non-caching modes
        SMARTSession smartSession = smart.startSession(party,true);
        // Construct a swap trade
        Trade trade = getSwapTrade();
        // Add the trade to the session - the trade is valued at this point
        // And as we are caching the trade, its valuation is added to the
        // session
        smartSession.addTrade(trade);
        // Let's get the trade valuation
        // As we have the trade cached only the trade id is required
        // to get the trade valuation
        TradeValuation tv = smartSession.getTradeValuation(trade.getTradeId());
        // Print the valuation out - due to the use of
        // protocol buffers the data is printed in a nice JSON like
        // format
        System.out.println(tv);
        // Now create a list for margin simulation
        // Create a list of simulation trades
        // This list can only includes a subset of the trades that are
        // already added to the session.
        ArrayList<TradeId> simulationTrades = new ArrayList<TradeId>();
        // Add the trade to the list - this trade must have been
        // already added to the session
        simulationTrades.add(trade.getTradeId());
        // Construct a simulation set containing the parameters we want to supply
        // to SMART; note that we are not supplying the list of sensitivities
        SimulationSet simulationSet = buildSimulationSet(account, simulationTrades, null);
        // Run margin simulation for the supplied set only
        // Session may have other trades and input sensitivity profiles
        // but these won't be included in the calculation
        SmartResultSet result = smartSession.calculateMarginEstimate(simulationSet);
        // Print the results
        System.out.println(result);
        // We are done!
        smartSession.close();
    }

    /**
     * Construct a sample swap trade
     */
    public static Trade getSwapTrade() {
        Trade trade = Trade.newBuilder()
                .setTradeId(TradeId.newBuilder().setId("-irsR449").build())
                .setTradeType(TradeType.IRS)
                .setCurrency("DKK")
                .setNotional(17000000)
                .setEffectiveDate(Date.newBuilder().setDay(19).setMonth(6).setYear(2014).build())
                .setTerminationDate(Date.newBuilder().setDay(19).setMonth(6).setYear(2019).build())
                .setPayLeg(
                        Leg.newBuilder()
                                .setLegType(LegType.FLOAT)
                                .setSpread(0.0)
                                .setPaymentFrequency("3M")
                                .setDayCountFraction("ACT/360").build()
                )
                .setReceiveLeg(
                        Leg.newBuilder()
                                .setLegType(LegType.FIXED)
                                .setFixedRate(3)
                                .setPaymentFrequency("12M")
                                .setDayCountFraction("ACT/ACT").build()
                ).build();
        return trade;
    }

    private static SimulationSet buildSimulationSet(String account,
                                                    ArrayList<TradeId> trades,
                                                    ArrayList<SensitivityProfile> sensitivityProfiles) {
        SimulationSet.Builder builder = SimulationSet.newBuilder();
        if (account != null)
            builder.setAccount(Account.newBuilder().setName(account).build());
        if (trades != null)
            for (TradeId trade : trades) builder.addTradeId(trade);
        if (sensitivityProfiles != null)
            for (SensitivityProfile sensitivityProfile : sensitivityProfiles)
                builder.addSensitivityProfileId(sensitivityProfile.getId());
        return builder.build();
    }

}
