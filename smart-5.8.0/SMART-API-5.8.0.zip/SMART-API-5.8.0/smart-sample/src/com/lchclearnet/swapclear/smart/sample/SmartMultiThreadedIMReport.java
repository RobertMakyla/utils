/**
 * Copyright (c) LCH Clearnet Ltd 2013
 */
package com.lchclearnet.swapclear.smart.sample;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.lchclearnet.exception.SystemException;
import com.lchclearnet.swapclear.smart.SMART;
import com.lchclearnet.swapclear.smart.SMARTDataProviderFactory;
import com.lchclearnet.swapclear.smart.SMARTFactory;
import com.lchclearnet.swapclear.smart.SMARTSession;
import com.lchclearnet.swapclear.smart.data.DataProviderFactory;
import com.lchclearnet.swapclear.smart.types.Account;
import com.lchclearnet.swapclear.smart.types.MarginEstimate;
import com.lchclearnet.swapclear.smart.types.SimulationSet;
import com.lchclearnet.swapclear.smart.types.SmartResultSet;
import com.lchclearnet.swapclear.smart.types.Trade;

/**
 * This sample program takes a trade input file and SwapClear EOD reports and
 * produces an IM report by counterparty.
 */
public class SmartMultiThreadedIMReport {

	/**
	 * Main.
	 */
	public static void main(String[] args) {

		if (args.length != 2) {
			usage();
		}
		String reportDir = args[0];
		String tradeFile = args[1];

		// Create a thread pool
		ExecutorService executorService = Executors.newFixedThreadPool(5 /* Runtime
				.getRuntime().availableProcessors()*/);
		try {
			// Create Trade objects from the content of the supplied CSV file.
			// ---------------------------------------------------------------
			Collection<Trade> trades = loadTrades(tradeFile);

			// Start by getting a DataProviderFactory which will be tied to a
			// report location.
			// -------------------------------------------------------------------------------
			DataProviderFactory dataProviderFactory = new SMARTDataProviderFactory(
					reportDir);

			// Instantiate the SMART Factory.
			// ------------------------------
			SMARTFactory smartFactory = new SMARTFactory();

			// Set the data provider factory and reporting currency.
			// -----------------------------------------------------
			smartFactory.setDataProviderFactory(dataProviderFactory);
			smartFactory.setReportingCurrency("GBP");

			// Create a SMART object tied to the business date.
			// Reports must be available for the given date.
			// ------------------------------------------------
			com.lchclearnet.dates.data.SimpleDate[] businessDates = dataProviderFactory.getBusinessDates();
			SMART smart = smartFactory.getSMARTInstance(businessDates[0]);

			ArrayList<Callable<MarginResult>> callables = new ArrayList<Callable<MarginResult>>();
			for (int i = 0; i < 3; i++) {
				callables.add(new MarginCalculator(smart, trades));
			}
			List<Future<MarginResult>> futures = executorService.invokeAll(callables);
			for (Future<MarginResult> f : futures) {
				try {
					MarginResult r = f.get();
					System.out.println("Result: errorCount=" + r.errorCount
							+ ", totalIM=" + r.initialMargin);
				} catch (InterruptedException e) {
				}
			}
			
			executorService.shutdown();

		} catch (Exception e) {
			e.printStackTrace();
			System.exit(1);
		}

	}

	static class MarginResult {
		public int errorCount;
		public double initialMargin;
	}

	static class MarginCalculator implements Callable<MarginResult> {

		SMART smart;
		Collection<Trade> trades;

		public MarginCalculator(SMART smart, Collection<Trade> trades) {
			this.smart = smart;
			this.trades = trades;
		}

		@Override
		public MarginResult call() {

			MarginResult mr = new MarginResult();

			// Dummy party / account
			String[] parties = new String[] { "FCM" };
			String[] accounts = new String[] { "H", "Client" };
			
			// Iterate over the counterparties defined for the trades we created
			// earlier.
			// --------------------------------------------------------------------------
			// for (String member : smart.getParties()) {
			for (String member: parties) {
				
				//for (String account : smart.getAccounts(member)) {
				for (String account: accounts) {

					// Start a SMART session.
					// The second boolean parameter says that we want the trades
					// and
					// sensitivities to be cached in the SMART session.
					// Please see the JavaDoc documentation of SMARTSession for
					// an
					// explanation of caching and non-caching modes.
					// -------------------------------------------------------------
					SMARTSession smartSession = smart.startSession(member,
							false);

					// Iterate over this counterparty's trades.
					// ---------------------------------------
					for (Trade t : trades) {
						try {
							smartSession.addTrade(t);
						} catch (SystemException e) {
							System.err
									.println(String
											.format("Failed to add trade [%s]. Error text is [%s].",
													t.getTradeId(),
													e.getMessage()));
							mr.errorCount++;
						}
					}

					// Build a simulation set containing the counterparty's
					// trades.
					// ------------------------------------------------------------
					SimulationSet simulationSet = buildSimulationSet(account,
							null);

					// Run a margin simulation for the trades in the simulation
					// set.
					// When the SMART session is in cached more, the SMART
					// session may contain
					// other trades and input sensitivity profiles, but only the
					// trades in the
					// simulation set will be included in the margin
					// calculation.
					// -----------------------------------------------------------------------
					SmartResultSet result = smartSession
							.calculateMarginEstimate(simulationSet);

					MarginEstimate margin = result.getMarginEstimate();

					mr.initialMargin += margin.getInitialMargin();

					// We are done. Close the SMART session.
					// -------------------------------------
					smartSession.close();
				}
			}
			return mr;
		}

	}

	/**
	 * Build a SimulationSet object containing the trades in the supplied
	 * collection.
	 */
	private static SimulationSet buildSimulationSet(String account,
			Collection<Trade> trades) {

		// Define a simulation set builder object.
		// ---------------------------------------
		SimulationSet.Builder builder = SimulationSet.newBuilder();

		if (account != null) {
			// Set the account. This is the counterparty from our input file.
			// The account is primarily
			// used to determine what sort of margin calculation will be
			// performed. If the account is
			// "H" then a House margin calculation will be performed. Any other
			// value will result in a
			// Client margin calculation. (Client IM = House IM * (7/5)^0.5)
			// ---------------------------------------------------------------------------------------
			builder.setAccount(Account.newBuilder().setName(account).build());
		}

		if (trades != null) {
			// Iterate over the trades, adding them to the simulation set
			// builder.
			// -------------------------------------------------------------------
			for (Trade trade : trades) {
				builder.addTradeId(trade.getTradeId());
			}
		}

		// Finally, build the Simulation Set object.
		// -----------------------------------------
		return builder.build();
	}

	static final class TradeLoader implements CSVReader.RecordHandler {

		ArrayList<Trade> trades = new ArrayList<Trade>();

		@Override
		public void process(String[] headings, String[] row) {

			// Build a Trade object from the information in this row of the
			// input file.
			// ------------------------------------------------------------------------
			Trade t = TradeBuilder.buildTrade(headings, row);
			trades.add(t);
		}
		
	}

	/**
	 * Parse a CSV formatted trade file and return the list of trades.
	 */
	public static Collection<Trade> loadTrades(String tradeInputFile) {

		TradeLoader tradeRecordHandler = new TradeLoader();
		CSVReader reader = new CSVReader(",");
		reader.process(tradeInputFile, tradeRecordHandler);
		return tradeRecordHandler.trades;
	}

	/**
	 * Usage.
	 */
	private static void usage() {

		System.out.println("Please supply two parameters:");
		System.out.println("\tPath to the reports");
		System.out.println("\tTrade file");
		System.exit(1);
	}

}