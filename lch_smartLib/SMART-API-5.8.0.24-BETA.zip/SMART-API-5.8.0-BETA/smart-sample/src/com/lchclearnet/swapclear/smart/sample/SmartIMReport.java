/**
 * Copyright (c) LCH Clearnet Ltd 2013
 */
package com.lchclearnet.swapclear.smart.sample;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.lchclearnet.exception.SystemException;
import com.lchclearnet.swapclear.smart.SMART;
import com.lchclearnet.swapclear.smart.SMARTDataProviderFactory;
import com.lchclearnet.swapclear.smart.SMARTFactory;
import com.lchclearnet.swapclear.smart.SMARTSession;
import com.lchclearnet.swapclear.smart.data.DataProviderFactory;
import com.lchclearnet.swapclear.smart.types.Account;
import com.lchclearnet.swapclear.smart.types.MarginEstimate;
import com.lchclearnet.swapclear.smart.types.SimulationSet;
import com.lchclearnet.swapclear.smart.types.SmartResultSet;
import com.lchclearnet.swapclear.smart.types.Trade;

/**
 * This sample program takes a trade input file and SwapClear EOD reports 
 * and produces an IM report by counterparty.
 */
public class SmartIMReport {

	/**
	 * Main.
	 */
	public static void main(String[] args) {

		if (args.length != 2) {
			usage();
		}
		String reportDir = args[0];
		String tradeFile = args[1];
		
		try {
			// Create Trade objects from the content of the supplied CSV file.
			// ---------------------------------------------------------------
			Map<String, Collection<Trade>> trades = loadTrades( tradeFile );
			
			// Define the output report and write a header record.
			// ---------------------------------------------------
			PrintStream ps = new PrintStream( new FileOutputStream( "report.txt" ) );
			
			// Start by getting a DataProviderFactory which will be tied to a report location.
			// -------------------------------------------------------------------------------
			DataProviderFactory dataProviderFactory = new SMARTDataProviderFactory( reportDir );
			
			// Instantiate the SMART Factory.
			// ------------------------------
			SMARTFactory smartFactory = new SMARTFactory();
			
			// Set the data provider factory and reporting currency.
			// -----------------------------------------------------
			smartFactory.setDataProviderFactory( dataProviderFactory );
			smartFactory.setReportingCurrency( "GBP" );
			
			// Create a SMART object tied to the business date.
			// Reports must be available for the given date.
			// ------------------------------------------------
			SMART smart = smartFactory.getSMARTInstance( dataProviderFactory.getBusinessDates()[0] );
			
			// Iterate over the counterparties defined for the trades we created earlier.
			// --------------------------------------------------------------------------
			for ( String counterparty : trades.keySet() ) {

				// Create a collection containing all of the trades for this counterparty.
				// -----------------------------------------------------------------------
				Collection<Trade> mytrades = trades.get(counterparty);
				
				// Define an empty collection. We'll load trades into this later.
				// --------------------------------------------------------------
				Collection<Trade> successTrades = new ArrayList<Trade>();
				
				// Start a SMART session.
				// The second boolean parameter says that we want the trades and
				// sensitivities to be cached in the SMART session.
				// Please see the JavaDoc documentation of SMARTSession for an 
				// explanation of caching and non-caching modes.
				// -------------------------------------------------------------
				SMARTSession smartSession = smart.startSession( counterparty, true );
				
				// Iterate over this counterparty's trades.
				// ---------------------------------------
				for ( Trade t : mytrades ) {
					
					try{
						smartSession.addTrade( t );
						successTrades.add( t );
					}
					catch ( SystemException e ){
						ps.println( String.format( "Failed to add trade [%s]. Error text is [%s].", t.getTradeId(), e.getMessage() ) );
					}
				}
				ps.println( "Party\t" + counterparty );
				
				// Build a simulation set containing the counterparty's trades.
				// ------------------------------------------------------------
				SimulationSet simulationSet = buildSimulationSet( counterparty, successTrades );
				
				// Run a margin simulation for the trades in the simulation set.
				// When the SMART session is in cached more, the SMART session may contain 
				// other trades and input sensitivity profiles, but only the trades in the 
				// simulation set will be included in the margin calculation.
				// -----------------------------------------------------------------------
				SmartResultSet result = smartSession.calculateMarginEstimate( simulationSet );
				
				MarginEstimate margin = result.getMarginEstimate();
				
				// Write the results to the output file.
				// -------------------------------------
				ps.println( "Currency            = " + margin.getReportingCurrency() );
				ps.println( "BASE IM             = " + margin.getInitialMargin() );
				ps.println( "IMM1                = " + margin.getMethod1InitialMarginMultiplier() );
				ps.println( "IMM2                = " + margin.getMethod2InitialMarginMultiplier() );
				ps.println( "Liquidity Add-on    = " + margin.getLiquidityAddOn() );
				ps.println( "Basis Risk Add-on   = " + margin.getBasisRiskAddOn() );
				ps.println( "Unscaled Var Add-On = " + margin.getUnscaledVarAddOn() );
				ps.println( "Total IM = " + margin.getTotalIm() );
				
				// We are done. Close the SMART session.
				// -------------------------------------
				smartSession.close();
			}
		} catch ( Exception e ) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Build a SimulationSet object containing the trades in the supplied collection.
	 */
	private static SimulationSet buildSimulationSet( String account, Collection<Trade> trades ) {

		// Define a simulation set builder object.
		// ---------------------------------------
		SimulationSet.Builder builder = SimulationSet.newBuilder();
		
		if ( account != null ) {
			// Set the account. This is the counterparty from our input file. The account is primarily
			// used to determine what sort of margin calculation will be performed. If the account is
			// "H" then a House margin calculation will be performed. Any other value will result in a
			// Client margin calculation. (Client IM = House IM * (7/5)^0.5)
			// ---------------------------------------------------------------------------------------
			builder.setAccount( Account.newBuilder()
					              .setName( account )
					              .build() );
		}
		
		if ( trades != null ) {
			// Iterate over the trades, adding them to the simulation set builder.
			// -------------------------------------------------------------------
			for ( Trade trade : trades ) {
				builder.addTradeId( trade.getTradeId() );
			}
		}
		
		// Finally, build the Simulation Set object.
		// -----------------------------------------
		return builder.build();
	}

	static final class TradeLoader implements CSVReader.RecordHandler {
		
		Map<String, Collection<Trade>> trades = new HashMap<String, Collection<Trade>>();

		@Override
		public void process( String[] headings, String[] row ) {
			
			// Build a Trade object from the information in this row of the input file.
			// ------------------------------------------------------------------------
			Trade t = TradeBuilder.buildTrade(headings, row);
			
			String counterparty = null;
			
			// Identify the counterparty. Basically we're looking for a column 
			// in the input file with the heading "counterparty".
			// ---------------------------------------------------------------
			for ( int i = 0 ; i < headings.length ; i++ ) {
				if ( headings[i].equalsIgnoreCase( "counterparty" ) ) {
					counterparty = row[i];
					break;
				}
			}
			
			// Throw an exception if no counterparty is defined.
			// -------------------------------------------------
			if ( counterparty == null ) {
				throw new SystemException("Counterparty field not set");
			}
			
			// Add the trade to an existing collection if one exists for this counterparty,
			// otherwise create a new collection and add the trade to that.
			// ----------------------------------------------------------------------------
			Collection<Trade> c = trades.get( counterparty );

			if ( c == null ) {
				c = new ArrayList<Trade>();
				trades.put(counterparty, c);
			}
			c.add(t);
		}
	}
		
	/**
	 * Parse a CSV formatted trade file and return the list of trades.
	 */
	public static Map<String, Collection<Trade>> loadTrades( String tradeInputFile ) {
		
		TradeLoader tradeRecordHandler = new TradeLoader();
		CSVReader reader = new CSVReader(",");
		reader.process( tradeInputFile, tradeRecordHandler );
		return tradeRecordHandler.trades;
	}	
	
	/**
	 * Usage.
	 */
	private static void usage() {
		
		System.out.println( "Please supply two parameters:" );
		System.out.println( "\tPath to the reports" );
		System.out.println( "\tTrade file" );
		System.exit(1);
	}

}