/**
 * Copyright (c) LCH Clearnet Ltd 2013
 */
package com.lchclearnet.swapclear.smart.sample;

import com.lchclearnet.swapclear.smart.types.CompoundingMethod;
import com.lchclearnet.swapclear.smart.types.Date;
import com.lchclearnet.swapclear.smart.types.InterpolationMethod;
import com.lchclearnet.swapclear.smart.types.Leg;
import com.lchclearnet.swapclear.smart.types.LegType;
import com.lchclearnet.swapclear.smart.types.RollConvention;
import com.lchclearnet.swapclear.smart.types.StubPosition;
import com.lchclearnet.swapclear.smart.types.StubType;
import com.lchclearnet.swapclear.smart.types.Trade;
import com.lchclearnet.swapclear.smart.types.TradeId;
import com.lchclearnet.swapclear.smart.types.TradeType;

/**
 * This sample replicates the CSV format accepted by the SMART API command line
 */
public class TradeBuilder {

	/**
	 * Build a trade from the CSV type input where headings are the field
	 * headings and row contains the data. The supported headings are:
	 * 
	 * <pre>
	 * tradeId - unique trade id
	 * tradeType - IRS, OIS, FRA or INF
	 * notional - notional amount, please ensure there are no commas in the value
	 * currency - Currency of the trade
	 * effectiveDate - For swaps unadjusted effective date - for FRAs adjusted effective date - must be in DD/MM/YYYY format
	 * terminationDate - For swaps unadjusted termination date - for FRAs adjusted termination date - must be in DD/MM/YYYY format
	 * payLegType - FLOAT or FIXED
	 * payIndexName - index name (optional expect for Libor/OIS basis swaps and Inflation leg of an Inflation Swap)
	 * payLegSpread - Spread (in basis points) if float, fixed rate (in percentage) if Fixed leg
	 * payLegPaymentPeriod - Payment frequency
	 * payLegDayCountFraction - Day count fraction
	 * payLegCompoundingMethod - Compounding method - STRAIGHT or FLAT
	 * payLegIndexPeriod - Index tenor if Float leg
	 * payLegStub - FL, FS, BL, BS where F = Front, B=Back, S=Short, L=Long 
	 * payInflationLevel - initial inflation index level (only for inflation swaps)
     * payInflationLag - Inflation lag in months (only for inflation swaps)
     * payInterpolationType - interpolation type - None OR Linear (only for inflation swaps)
	 * recLegType
	 * recLegSpread
	 * recIndexName
	 * recLegPaymentPeriod
	 * recLegDayCountFraction
	 * recLegCompoundingMethod
	 * recLegIndexPeriod
	 * recLegStub 
	 * recInflationLevel - initial inflation index level (only for inflation swaps)
     * recInflationLag - Inflation lag in months (only for inflation swaps)
     * recInterpolationType - interpolation type - None OR Linear (only for inflation swaps)
	 * rollConvention - EOM, IMM, IMMAUD, IMMNZD or IMMCAD, otherwise leave blank
	 * </pre>
	 */
	public static Trade buildTrade(String[] headings, String[] row) {
		Trade.Builder tradeBuilder = Trade.newBuilder();
		Leg.Builder payLegBuilder = Leg.newBuilder();
		Leg.Builder recLegBuilder = Leg.newBuilder();
		boolean interpolate = false;
		for (int i = 0; i < Math.min(row.length, headings.length); i++) {
			String h = headings[i];
			String f = row[i];
			Leg.Builder legBuilder = payLegBuilder;
			if (h.toUpperCase().startsWith("REC")) {
				legBuilder = recLegBuilder;
			}
			if (h.equalsIgnoreCase("tradeId")) {
				tradeBuilder.setTradeId(TradeId.newBuilder().setId(f));
			} else if (h.equalsIgnoreCase("tradeType")) {
				TradeType t = getTradeType(f);
				if (t != null)
					tradeBuilder.setTradeType(t);
			} else if (h.equalsIgnoreCase("notional")) {
				tradeBuilder.setNotional(getDouble(f));
			} else if (h.equalsIgnoreCase("currency")) {
				tradeBuilder.setCurrency(f);
			} else if(h.equalsIgnoreCase("recInflationLevel") ||
					h.equalsIgnoreCase("payInflationLevel")){
				if (f != null && !f.isEmpty())
					legBuilder.setInitialInflationLevel(Double.parseDouble(f));
			}else if(h.equalsIgnoreCase("payInflationLag") ||
					h.equalsIgnoreCase("recInflationLag")){
				if (f != null && !f.isEmpty())
					legBuilder.setInflationLag(Integer.parseInt(f));
			}else if (h.equalsIgnoreCase("recInterpolationType") ||
					h.equalsIgnoreCase("payInterpolationType")){
				if (f != null && !f.isEmpty())
					legBuilder.setInflationInterpolationMethod(InterpolationMethod.valueOf(f.toUpperCase()));
			}else if (h.equalsIgnoreCase("effectiveDate")) {
				Date d = makeDate(f);
				if (d != null)
					tradeBuilder.setEffectiveDate(d);
			} else if (h.equalsIgnoreCase("terminationDate")) {
				Date d = makeDate(f);
				if (d != null)
					tradeBuilder.setTerminationDate(d);
			} else if (h.equalsIgnoreCase("payLegType")
					|| h.equalsIgnoreCase("recLegType")) {
				LegType lt = getLegType(f);
				if (lt != null)
					legBuilder.setLegType(lt);
			} else if (h.equalsIgnoreCase("payLegSpread")
					|| h.equalsIgnoreCase("recLegSpread")) {
				legBuilder.setSpread(getDouble(f));
			}else if(h.equalsIgnoreCase("payLegPaymentPeriod")){
				payLegBuilder.setPaymentFrequency(getPaymentFrequency(f));
			}else if(h.equalsIgnoreCase("recLegPaymentPeriod")){
				recLegBuilder.setPaymentFrequency(getPaymentFrequency(f));
			}else if(h.equalsIgnoreCase("payIndexName")){
				payLegBuilder.setIndexName(f);
			}else if(h.equalsIgnoreCase("recIndexName")){
				recLegBuilder.setIndexName(f);
			}else if(h.equalsIgnoreCase("payLegDayCountFraction")){
				payLegBuilder.setDayCountFraction(f);
			}else if(h.equalsIgnoreCase("recLegDayCountFraction")) {
				recLegBuilder.setDayCountFraction(f);
			}			
			else if (h.equalsIgnoreCase("payLegCompoundingMethod")
					|| h.equalsIgnoreCase("recLegCompoundingMethod")) {
				CompoundingMethod cm = getCompoundingMethod(f);
				if (cm != null)
					legBuilder.setCompoundingMethod(cm);
			} else if (h.equalsIgnoreCase("payLegIndexPeriod")
					|| h.equalsIgnoreCase("recLegIndexPeriod")) {
				if (!f.equalsIgnoreCase("i")) {
					legBuilder.setIndexTenor(f);
				} else {
					interpolate = true;
				}
			} else if (h.equalsIgnoreCase("payLegStubLS")
					|| h.equalsIgnoreCase("recLegStubLS")) {
				StubType st = getStubType(f);
				if (st != null)
					legBuilder.setStubType(st);
			} else if (h.equalsIgnoreCase("payLegStubFB")
					|| h.equalsIgnoreCase("recLegStubFB")) {
				StubPosition sp = getStubPosition(f);
				if (sp != null)
					legBuilder.setStubPosition(sp);
			} else if (h.equalsIgnoreCase("rollConvention")) {
				RollConvention rc = getRollConvention(f);
				if (rc != null) {
					payLegBuilder.setRollConvention(rc);
					recLegBuilder.setRollConvention(rc);
				}
			} else if (h.equalsIgnoreCase("payLegStub")
					|| h.equalsIgnoreCase("recLegStub")) {
				parseStub(legBuilder, f);
			}
		}
		if (tradeBuilder.getTradeType() == TradeType.OIS) {
		} else if (tradeBuilder.getTradeType() == TradeType.FRA && interpolate) {
			if (payLegBuilder.getLegType() == LegType.FLOAT) {
				payLegBuilder.setInterpolate(true);
			} else if (recLegBuilder.getLegType() == LegType.FLOAT) {
				recLegBuilder.setInterpolate(true);
			}
		}
		// fixed rate and spread are in the same field
		// so we need to put the rate in the correct field.
		if (payLegBuilder.getLegType() == LegType.FIXED) {
			fixupFixedRate(payLegBuilder);
		} else if (recLegBuilder.getLegType() == LegType.FIXED) {
			fixupFixedRate(recLegBuilder);
		}
		tradeBuilder.setPayLeg(payLegBuilder.build());
		tradeBuilder.setReceiveLeg(recLegBuilder.build());
		return tradeBuilder.build();
	}
	
	private static String getPaymentFrequency(String freq) {
		if (freq.equals("ZERO C"))
			freq = "1T";
		else if (freq.equals("1Y"))
			freq = "12M";
		return freq;
	}

	private static double getDouble(String f) {
		if (f == null || f.length() == 0) {
			return 0.0;
		}
		try {
			return Double.valueOf(f).doubleValue();
		} catch (NumberFormatException e) {
			throw new IllegalArgumentException("Bad number " + f);
		}
	}

	private static Date makeDate(String s) {
		try {
			int day = Integer.valueOf(s.substring(0, 2)).intValue();
			int month = Integer.valueOf(s.substring(3, 5)).intValue();
			int year = Integer.valueOf(s.substring(6, 10)).intValue();
			return Date.newBuilder().setDay(day).setMonth(month).setYear(year)
					.build();
		} catch (NumberFormatException e) {
			throw new IllegalArgumentException("Invalid date " + s
					+ "; support format is DD/MM/YYYY");
		}
	}

	private static void parseStub(Leg.Builder legBuilder, String f) {
		if (f == null || f.length() == 0) {
			return;
		}
		StubPosition pos = null;
		StubType type = null;
		if (f.indexOf('f') >= 0 || f.indexOf('F') >= 0) {
			pos = StubPosition.FRONT;
		} else if (f.indexOf('b') >= 0 || f.indexOf('B') >= 0) {
			pos = StubPosition.BACK;
		}
		if (f.indexOf('l') >= 0 || f.indexOf('L') >= 0) {
			type = StubType.LONG;
		} else if (f.indexOf('s') >= 0 || f.indexOf('S') >= 0) {
			type = StubType.SHORT;
		}
		if (pos == null || type == null) {
			throw new IllegalArgumentException("Invalid stub " + f);
		}
		legBuilder.setStubPosition(pos);
		legBuilder.setStubType(type);
	}

	private static void fixupFixedRate(Leg.Builder legBuilder) {
		legBuilder.setFixedRate(legBuilder.getSpread());
		legBuilder.setSpread(0);
	}

	private static TradeType getTradeType(String f) {
		if (f == null || f.length() == 0) {
			throw new IllegalArgumentException("Invalid trade type " + f);
		}
		try {
			return TradeType.valueOf(f);
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid trade type " + f, e);
		}
	}

	private static LegType getLegType(String f) {
		if (f == null || f.length() == 0)
			throw new IllegalArgumentException("Invalid leg type " + f);
		try {
			return LegType.valueOf(f);
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid leg type " + f, e);
		}
	}

	private static CompoundingMethod getCompoundingMethod(String f) {
		if (f == null || f.length() == 0)
			return null;
		try {
			return CompoundingMethod.valueOf(f);
		} catch (Exception e) {
			throw new IllegalArgumentException(
					"Invalid compounding method " + f, e);
		}
	}

	private static StubType getStubType(String f) {
		if (f == null || f.length() == 0)
			return null;
		try {
			return StubType.valueOf(f);
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid stub type " + f, e);
		}
	}

	private static StubPosition getStubPosition(String f) {
		if (f == null || f.length() == 0)
			return null;
		try {
			return StubPosition.valueOf(f);
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid stub position " + f, e);
		}
	}

	private static RollConvention getRollConvention(String f) {
		if (f == null || f.length() == 0)
			return null;
		try {
			return RollConvention.valueOf(f);
		} catch (Exception e) {
			throw new IllegalArgumentException("Invalid roll convention " + f, e);
		}
	}
}
