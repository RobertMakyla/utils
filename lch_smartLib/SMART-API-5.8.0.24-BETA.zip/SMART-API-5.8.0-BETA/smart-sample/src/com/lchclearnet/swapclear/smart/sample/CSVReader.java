/**
 * Copyright (c) LCH Clearnet Ltd 2013
 */
package com.lchclearnet.swapclear.smart.sample;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import com.lchclearnet.exception.SystemException;

/**
 * Generic CSV file processor - expects the first row to contain a header row
 */
public class CSVReader {

    public static interface RecordHandler {
        void process(String[] headings, String[] row);
    }

    String delimCh;

    public CSVReader(String delimCh) {
        this.delimCh = delimCh;
    }
    
	/**
	 * Parse a comma delimited line and return the fields.
	 * Fields may be optionally enclosed in double quotes.
	 * Fields going across multiple lines are not supported.
	 */
	static String[] parseCSVLine(String line, char delim) {
		ArrayList<String> row = new ArrayList<String>();
		int pos = 0;
		boolean quoted = false;
		while (pos < line.length()) {
			if (line.charAt(pos) != '"') {
				quoted = false;
			} else {
				quoted = true;
				pos++;
			}
			if (quoted) {
				int nextQuote = line.indexOf('"', pos);
				if (nextQuote == -1) {
					break;
				}
				String value = line.substring(pos, nextQuote).trim();
				row.add(value);
				pos = ++nextQuote;
			} else {
				int nextField = line.indexOf(delim, pos);
				if (nextField == -1) {
					nextField = line.length();
					// break;
				}
				String value = line.substring(pos, nextField).trim();
				row.add(value);
				pos = nextField;
			}
			if (pos >= line.length() || line.charAt(pos) != delim) {
				break;
			}
			pos++;
			if (pos == line.length()) {
				// last field is empty
				row.add("");
				break;
			}
		}
		return row.toArray(new String[row.size()]);
	}

    void processFile(String filename, InputStreamReader freader, RecordHandler handler) {
        try {
        	int lineNo = 0;
            BufferedReader reader = new BufferedReader(freader);
            String line;
            String[] headings = null;
            for (lineNo = 1; ((line = reader.readLine()) != null); lineNo++) {
            	if (delimCh.length() == 1)
                    headings = parseCSVLine(line, delimCh.charAt(0));
            	else
            		headings = line.split(delimCh);
            	break;
            }
            if (headings == null) {
            	System.err.println("No data found in [" + filename + "]");
            	return;
            }
            String[] row;
            for (; ((line = reader.readLine()) != null); lineNo++) {
            	// comments start with a # - ignore those
            	if ( line != null && 
            			!line.isEmpty() &&
            			line.charAt(0) == '#')
            		continue;
            	
            	if (delimCh.length() == 1)
                    row = parseCSVLine(line, delimCh.charAt(0));
            	else
            		row = line.split(delimCh);
                try {
                    handler.process(headings, row);
                } catch (Exception e) {
                    System.err.println("Failed to process line [" + lineNo + "] " + line);
                    System.err.println("Error: " + e.getMessage());
                }
            }
        } catch (SystemException e) {
            throw e;
        } catch (Exception e) {
        	throw new SystemException("Error occurred when reading from file " + filename, e);
        }
    }

    public void process(String filename, RecordHandler handler) {
        InputStreamReader freader = null;
        try {
            freader = new InputStreamReader(new FileInputStream(filename));
            System.out.println("Processing [" + filename + "]");
            processFile(filename, freader, handler);
        } catch (FileNotFoundException e) {
			throw new SystemException("Error opening file " + filename, e);
		} finally {
            try {
                if (freader != null)
                    freader.close();
            } catch (IOException ignored) {
            }
        }
    }
}
